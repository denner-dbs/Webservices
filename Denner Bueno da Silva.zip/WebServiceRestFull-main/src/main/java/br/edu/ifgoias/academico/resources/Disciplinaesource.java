import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/disciplinas")
public class DisciplinaController {

    @Autowired
    private DisciplinaService disciplinaService;

    @GetMapping
    public List<Disciplina> listarDisciplinas() {
        return disciplinaService.listarTodas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Disciplina> procurarDisciplina(@PathVariable Long id) {
        Disciplina disciplina = disciplinaService.procurarPorId(id);
        return disciplina != null ? ResponseEntity.ok(disciplina) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public Disciplina inserirDisciplina(@RequestBody Disciplina disciplina) {
        return disciplinaService.inserir(disciplina);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Disciplina> alterarDisciplina(@PathVariable Long id, @RequestBody Disciplina disciplina) {
        Disciplina updatedDisciplina = disciplinaService.alterar(id, disciplina);
        return updatedDisciplina != null ? ResponseEntity.ok(updatedDisciplina) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirDisciplina(@PathVariable Long id) {
        disciplinaService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
