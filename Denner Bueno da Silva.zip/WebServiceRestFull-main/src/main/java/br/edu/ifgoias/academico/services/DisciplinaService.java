package br.edu.ifgoias.academico.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import br.edu.ifgoias.academico.entities.Disciplina;
import br.edu.ifgoias.academico.repositories.DisciplinaRepository;

import java.util.List;

@Service
public class DisciplinaService {

    @Autowired
    private DisciplinaRepository disciplinaRepository;

    public List<Disciplina> listarTodas() {
        return disciplinaRepository.findAll();
    }

    public Disciplina procurarPorId(Long id) {
        return disciplinaRepository.findById(id).orElse(null);
    }

    public Disciplina inserir(Disciplina disciplina) {
        return disciplinaRepository.save(disciplina);
    }

    public Disciplina alterar(Long id, Disciplina disciplina) {
        if (disciplinaRepository.existsById(id)) {
            disciplina.setId(id);
            return disciplinaRepository.save(disciplina);
        }
        return null;
    }

    public void excluir(Long id) {
        disciplinaRepository.deleteById(id);
    }
}
